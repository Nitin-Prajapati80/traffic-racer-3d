# Highway Rush 3D

A free, browser-based 3D highway racing starter project built with React, Vite and Three.js.

## Requirements
- Node.js LTS
- A modern browser with WebGL support
- GitHub account and Vercel account for deployment (free tiers)

## Run locally
1. Install Node.js from https://nodejs.org/
2. Extract this project and open its folder in VS Code.
3. Open a terminal in the project folder.
4. Run:
   ```bash
   npm install
   npm run dev
   ```
5. Open the local URL printed by Vite, usually `http://localhost:5173`.

## Build check
```bash
npm run build
npm run preview
```

## Controls
- Arrow keys / WASD: steer and accelerate/brake
- Space / Shift: nitro
- P: pause/resume
- Mobile: hold on-screen steering, nitro, brake and go buttons

## Deploy to Vercel
1. Create a GitHub repository.
2. Upload all project files (including `src/`, `package.json`, `index.html`).
3. In Vercel, choose **Add New → Project** and import that repository.
4. Framework preset: Vite (usually detected automatically).
5. Build command: `npm run build`
6. Output directory: `dist`
7. Click Deploy.

No paid API, database, or backend is required for this version. Vercel and GitHub free-tier limits and terms can change. This project uses simple original low-poly geometry rather than external copyrighted game assets.

## Current starter-build notes
- This is a playable starter, not a finished AAA title.
- Traffic collision slows the car and deducts points; this build does not yet end a run on collision.
- Sound toggle is a UI placeholder; sound effects are not implemented yet.
- Art is procedural low-poly geometry. Later improvements can add licensed car/environment models, engine audio, settings, richer roadside scenery and a proper race progression system.
