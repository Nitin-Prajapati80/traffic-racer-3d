import React, { useCallback, useEffect, useRef, useState } from "react";
import * as THREE from "three";

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const LANES = [-3.2, 0, 3.2];
const ROAD_WIDTH = 11.2;
const SEGMENT_LENGTH = 45;
const SEGMENT_COUNT = 8;

function makeMaterial(color, roughness = 0.8, metalness = 0) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness });
}

function box(parent, name, size, material, position, cast = true) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.name = name;
  mesh.position.set(...position);
  mesh.castShadow = cast;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function makeCar(color = 0x168bff, player = false) {
  const group = new THREE.Group();
  const bodyMat = makeMaterial(color, 0.32, 0.22);
  const glassMat = new THREE.MeshStandardMaterial({
    color: player ? 0x142a3c : 0x1a2733,
    roughness: 0.18, metalness: 0.12, transparent: true, opacity: 0.92
  });
  const tireMat = makeMaterial(0x111318, 0.95);
  const rimMat = makeMaterial(0x9ca9b7, 0.3, 0.75);
  box(group, "body", [1.75, 0.52, 3.5], bodyMat, [0, 0.62, 0]);
  box(group, "hood", [1.62, 0.18, 1.08], bodyMat, [0, 0.91, -1.05]);
  box(group, "cabin", [1.32, 0.67, 1.45], glassMat, [0, 1.1, 0.16]);
  box(group, "roof", [1.18, 0.12, 0.84], bodyMat, [0, 1.48, 0.15]);
  const headMat = new THREE.MeshBasicMaterial({ color: 0xfff3ce });
  const tailMat = new THREE.MeshBasicMaterial({ color: 0xff263c });
  box(group, "headlightL", [0.36, 0.14, 0.07], headMat, [-0.55, 0.72, -1.78], false);
  box(group, "headlightR", [0.36, 0.14, 0.07], headMat, [0.55, 0.72, -1.78], false);
  box(group, "tailL", [0.36, 0.15, 0.07], tailMat, [-0.55, 0.72, 1.78], false);
  box(group, "tailR", [0.36, 0.15, 0.07], tailMat, [0.55, 0.72, 1.78], false);

  for (const x of [-0.91, 0.91]) {
    for (const z of [-1.1, 1.1]) {
      const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.19, 12), tireMat);
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(x, 0.38, z);
      wheel.castShadow = true;
      group.add(wheel);
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.17, 0.2, 10), rimMat);
      rim.rotation.z = Math.PI / 2;
      rim.position.copy(wheel.position);
      group.add(rim);
    }
  }
  group.userData.isPlayer = player;
  return group;
}

function createWorld(scene) {
  const roadMat = makeMaterial(0x252a31, 0.96);
  const shoulderMat = makeMaterial(0x60676d, 1);
  const grassMat = makeMaterial(0x244c2d, 1);
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xf1f0dd });
  const yellowMat = new THREE.MeshBasicMaterial({ color: 0xf5c84b });
  const segments = [];

  for (let i = 0; i < SEGMENT_COUNT; i++) {
    const g = new THREE.Group();
    g.position.z = -i * SEGMENT_LENGTH;
    const road = new THREE.Mesh(new THREE.PlaneGeometry(ROAD_WIDTH, SEGMENT_LENGTH), roadMat);
    road.rotation.x = -Math.PI / 2;
    road.position.y = -0.04;
    road.receiveShadow = true;
    g.add(road);

    for (const x of [-ROAD_WIDTH / 2 - 0.55, ROAD_WIDTH / 2 + 0.55]) {
      const shoulder = new THREE.Mesh(new THREE.PlaneGeometry(1.1, SEGMENT_LENGTH), shoulderMat);
      shoulder.rotation.x = -Math.PI / 2;
      shoulder.position.set(x, -0.035, 0);
      g.add(shoulder);
    }
    for (const x of [-ROAD_WIDTH / 2, ROAD_WIDTH / 2]) {
      const line = new THREE.Mesh(new THREE.PlaneGeometry(0.12, SEGMENT_LENGTH), yellowMat);
      line.rotation.x = -Math.PI / 2;
      line.position.set(x, 0.005, 0);
      g.add(line);
    }
    for (const x of [-ROAD_WIDTH / 6, ROAD_WIDTH / 6]) {
      for (let z = -SEGMENT_LENGTH / 2 + 3; z < SEGMENT_LENGTH / 2; z += 9) {
        const dash = new THREE.Mesh(new THREE.PlaneGeometry(0.09, 4.2), lineMat);
        dash.rotation.x = -Math.PI / 2;
        dash.position.set(x, 0.006, z);
        g.add(dash);
      }
    }
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(160, SEGMENT_LENGTH), grassMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(0, -0.09, 0);
    g.add(ground);

    // Simple roadside posts, deliberately low-poly for performance.
    for (const side of [-1, 1]) {
      for (let z = -SEGMENT_LENGTH / 2 + 6; z < SEGMENT_LENGTH / 2; z += 15) {
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.9, 0.13), makeMaterial(0xe0e4e5));
        post.position.set(side * (ROAD_WIDTH / 2 + 1.1), 0.43, z);
        g.add(post);
      }
    }
    scene.add(g);
    segments.push(g);
  }
  return segments;
}

function App() {
  const mountRef = useRef(null);
  const gameRef = useRef(null);
  const keysRef = useRef({ left: false, right: false, accel: false, brake: false, nitro: false });
  const [gameState, setGameState] = useState("menu");
  const [hud, setHud] = useState({ speed: 0, score: 0, distance: 0, nitro: 100, best: 0 });
  const [soundOn, setSoundOn] = useState(false);
  const [mobile, setMobile] = useState(false);

  useEffect(() => setMobile(window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 800), []);

  const startGame = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    g.speed = 22;
    g.score = 0;
    g.distance = 0;
    g.playerX = 0;
    g.nitro = 100;
    g.invulnerable = 0;
    g.traffic.forEach((car, i) => {
      car.visible = i < 7;
      car.position.set(LANES[Math.floor(Math.random() * LANES.length)], 0, -35 - i * 34);
      car.userData.speed = 8 + Math.random() * 14;
      car.userData.lane = Math.round((car.position.x + 3.2) / 3.2);
    });
    g.player.position.set(0, 0, 0);
    g.player.rotation.set(0, 0, 0);
    g.camera.position.set(0, 1.68, 1.1);
    g.camera.rotation.set(0, 0, 0);
    g.camera.lookAt(0, 1.42, -22);
    g.running = true;
    setGameState("playing");
    setHud({ speed: 0, score: 0, distance: 0, nitro: 100, best: Number(localStorage.getItem("hr3d-best") || 0) });
  }, []);

  const pauseGame = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    g.running = false;
    setGameState("paused");
  }, []);

  const resumeGame = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    g.running = true;
    setGameState("playing");
  }, []);

  const endGame = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    g.running = false;
    const best = Math.max(Number(localStorage.getItem("hr3d-best") || 0), Math.floor(g.score));
    localStorage.setItem("hr3d-best", String(best));
    setHud(h => ({ ...h, best }));
    setGameState("over");
  }, []);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x8bc8ee);
    scene.fog = new THREE.Fog(0x8bc8ee, 55, 240);

    const camera = new THREE.PerspectiveCamera(72, mount.clientWidth / mount.clientHeight, 0.1, 400);
    camera.position.set(0, 2.15, 4.7);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.65));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.shadowMap.enabled = false;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    mount.appendChild(renderer.domElement);

    scene.add(new THREE.HemisphereLight(0xd8efff, 0x394a30, 2.0));
    const sun = new THREE.DirectionalLight(0xfff3d6, 2.1);
    sun.position.set(-18, 35, 15);
    scene.add(sun);

    const worldSegments = createWorld(scene);
    const player = makeCar(0x147dff, true);
    player.position.set(0, 0, 0);
    scene.add(player);

    // Driver-view camera is inside the vehicle, looking forward over the hood.
    camera.position.set(0, 1.53, -0.02);
    camera.rotation.set(0, 0, 0);
    player.add(camera);
    camera.position.set(0, 1.53, -0.02);
    camera.rotation.set(0, 0, 0);
    // Reparenting camera to player makes cockpit view follow steering; remove camera's world-parent effect.
    player.remove(camera);
    scene.add(camera);
    camera.position.set(0, 1.68, 1.1);
    camera.lookAt(0, 1.42, -22);

    const trafficColors = [0xff4c45, 0xffc247, 0xeeeeee, 0x2e343c, 0x2bb673, 0x9b70ff, 0x11b7c9];
    const traffic = [];
    for (let i = 0; i < 9; i++) {
      const car = makeCar(trafficColors[i % trafficColors.length], false);
      car.scale.setScalar(0.94 + Math.random() * 0.1);
      car.position.set(LANES[i % 3], 0, -35 - i * 32);
      car.userData.speed = 8 + Math.random() * 14;
      car.visible = i < 7;
      scene.add(car);
      traffic.push(car);
    }

    const g = {
      scene, camera, renderer, player, traffic, worldSegments,
      running: false, speed: 0, score: 0, distance: 0, playerX: 0,
      nitro: 100, invulnerable: 0, lastHud: 0, clock: new THREE.Clock()
    };
    gameRef.current = g;

    let raf = 0;
    const animate = () => {
      raf = requestAnimationFrame(animate);
      const dt = Math.min(g.clock.getDelta(), 0.04);
      const now = performance.now();

      if (g.running) {
        const keys = keysRef.current;
        const usingNitro = keys.nitro && g.nitro > 0;
        const targetSpeed = keys.brake ? 7 : (keys.accel ? 43 : 29) + (usingNitro ? 17 : 0);
        g.speed = THREE.MathUtils.damp(g.speed, targetSpeed, keys.brake ? 4.0 : 1.15, dt);
        if (usingNitro) g.nitro = Math.max(0, g.nitro - 28 * dt);
        else g.nitro = Math.min(100, g.nitro + 7.5 * dt);

        const steer = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
        g.playerX = clamp(g.playerX + steer * dt * (2.6 + g.speed * 0.055), -4.25, 4.25);
        g.player.position.x = THREE.MathUtils.damp(g.player.position.x, g.playerX * 0.25, 7, dt);
        g.player.rotation.z = THREE.MathUtils.damp(g.player.rotation.z, -steer * 0.055, 5, dt);

        // Keep the player camera forward-facing with a tiny steering sway.
        g.camera.position.x = THREE.MathUtils.damp(g.camera.position.x, steer * -0.08, 3, dt);
        g.camera.position.y = 1.65 + Math.sin(now * 0.008) * (g.speed / 43) * 0.012;
        g.camera.lookAt(g.player.position.x * 0.15, 1.42, -22);

        const travel = g.speed * dt;
        g.distance += travel;
        g.score += travel * 0.85;
        worldSegments.forEach(seg => {
          seg.position.z += travel;
          if (seg.position.z > SEGMENT_LENGTH) seg.position.z -= SEGMENT_LENGTH * SEGMENT_COUNT;
        });

        for (const car of g.traffic) {
          car.position.z += (g.speed - car.userData.speed) * dt;
          if (car.position.z > 10) {
            car.position.z = -160 - Math.random() * 100;
            const lane = Math.floor(Math.random() * 3);
            car.position.x = LANES[lane];
            car.userData.lane = lane;
            car.userData.speed = 8 + Math.random() * 17;
            car.visible = true;
          }
          // Simple collision test in player-relative space.
          if (g.invulnerable <= 0 && Math.abs(car.position.z - g.player.position.z) < 2.8 &&
              Math.abs(car.position.x - g.player.position.x) < 1.55) {
            g.speed *= 0.35;
            g.invulnerable = 1.3;
            g.score = Math.max(0, g.score - 120);
            g.player.position.x = clamp(g.player.position.x + (g.player.position.x <= car.position.x ? -0.45 : 0.45), -4.2, 4.2);
          }
        }
        g.invulnerable = Math.max(0, g.invulnerable - dt);

        if (Math.abs(g.playerX) > 3.75) g.speed = Math.max(8, g.speed - 10 * dt);
        if (now - g.lastHud > 100) {
          g.lastHud = now;
          setHud({
            speed: Math.round(g.speed * 3.6),
            score: Math.floor(g.score),
            distance: (g.distance / 1000).toFixed(2),
            nitro: Math.round(g.nitro),
            best: Number(localStorage.getItem("hr3d-best") || 0)
          });
        }
      }
      renderer.render(scene, camera);
    };
    animate();

    const resize = () => {
      const w = mount.clientWidth || window.innerWidth;
      const h = mount.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.65));
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", resize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      scene.traverse(obj => {
        if (obj.geometry) obj.geometry.dispose();
        if (obj.material) {
          if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
          else obj.material.dispose();
        }
      });
      renderer.dispose();
      if (renderer.domElement.parentNode === mount) mount.removeChild(renderer.domElement);
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    const keyMap = {
      ArrowLeft: "left", a: "left", A: "left",
      ArrowRight: "right", d: "right", D: "right",
      ArrowUp: "accel", w: "accel", W: "accel",
      ArrowDown: "brake", s: "brake", S: "brake",
      " ": "nitro", Shift: "nitro"
    };
    const down = e => {
      if (keyMap[e.key]) {
        e.preventDefault();
        keysRef.current[keyMap[e.key]] = true;
      }
      if (e.key.toLowerCase() === "p" && gameState === "playing") pauseGame();
      else if (e.key.toLowerCase() === "p" && gameState === "paused") resumeGame();
    };
    const up = e => { if (keyMap[e.key]) keysRef.current[keyMap[e.key]] = false; };
    window.addEventListener("keydown", down, { passive: false });
    window.addEventListener("keyup", up);
    const blur = () => { keysRef.current = { left: false, right: false, accel: false, brake: false, nitro: false }; };
    window.addEventListener("blur", blur);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", blur);
    };
  }, [gameState, pauseGame, resumeGame]);

  const bindControl = (name) => ({
    onPointerDown: e => { e.preventDefault(); keysRef.current[name] = true; e.currentTarget.setPointerCapture?.(e.pointerId); },
    onPointerUp: e => { e.preventDefault(); keysRef.current[name] = false; },
    onPointerCancel: () => { keysRef.current[name] = false; },
    onContextMenu: e => e.preventDefault()
  });

  return (
    <main className="game-shell">
      <div className="scene" ref={mountRef} />
      <div className="vignette" />
      <header className="topbar">
        <div className="brand"><span className="brand-mark">HR</span><span>HIGHWAY <b>RUSH</b><small>3D DRIVE</small></span></div>
        <div className="top-actions">
          <button className="icon-button" onClick={() => setSoundOn(v => !v)} aria-label="Toggle sound" title="Sound is not included in this starter build">{soundOn ? "♫" : "♪"} <span>{soundOn ? "ON" : "OFF"}</span></button>
          {gameState === "playing" && <button className="icon-button" onClick={pauseGame}>Ⅱ <span>PAUSE</span></button>}
        </div>
      </header>

      <section className="hud">
        <div className="hud-card speed-card">
          <div className="eyebrow">SPEED <span>KM/H</span></div>
          <div className="speed-value">{hud.speed}<small> km/h</small></div>
          <div className="speed-track"><i style={{ width: `${Math.min(100, hud.speed / 180 * 100)}%` }} /></div>
        </div>
        <div className="hud-card score-card"><div className="eyebrow">DISTANCE</div><div className="metric">{hud.distance}<small> km</small></div></div>
        <div className="hud-card score-card"><div className="eyebrow">SCORE</div><div className="metric">{hud.score.toLocaleString("en-US")}</div></div>
      </section>

      <div className="nitro-panel">
        <div className="nitro-heading"><span>⚡ NITRO</span><b>{hud.nitro}%</b></div>
        <div className="nitro-track"><i style={{ width: `${hud.nitro}%` }} /></div>
      </div>

      <div className="lane-label"><span>DRIVER VIEW</span><i /> HIGHWAY MODE</div>

      {gameState === "menu" && <div className="overlay">
        <div className="modal hero-modal">
          <div className="pill"><i /> FREE BROWSER RACING</div>
          <h1>HIGHWAY<br/><span>RUSH 3D</span></h1>
          <p>Own the road. Beat the traffic.</p>
          <div className="feature-row"><span>◈ 3D DRIVER VIEW</span><span>⚡ NITRO BOOST</span><span>↗ TRAFFIC DODGE</span></div>
          <button className="primary-button" onClick={startGame}>START ENGINE <span>↗</span></button>
          <small className="hint">WASD / ARROW KEYS · SHIFT / SPACE FOR NITRO</small>
        </div>
      </div>}

      {gameState === "paused" && <div className="overlay"><div className="modal compact-modal">
        <div className="pill">RACE PAUSED</div><h2>Take a breath.</h2><p>Your highway is waiting.</p>
        <button className="primary-button" onClick={resumeGame}>RESUME RACE <span>▶</span></button>
        <button className="secondary-button" onClick={startGame}>RESTART</button>
      </div></div>}

      {gameState === "over" && <div className="overlay"><div className="modal compact-modal">
        <div className="pill danger-pill">RUN ENDED</div><h2>Traffic got you.</h2><p>Score <b>{hud.score.toLocaleString("en-US")}</b> · Best <b>{hud.best.toLocaleString("en-US")}</b></p>
        <button className="primary-button" onClick={startGame}>RACE AGAIN <span>↗</span></button>
      </div></div>}

      {gameState === "playing" && <div className="control-hint">← → STEER <span>·</span> ↑ ACCELERATE <span>·</span> SPACE NITRO</div>}

      {mobile && gameState === "playing" && <div className="mobile-controls">
        <div className="steering-controls">
          <button {...bindControl("left")} aria-label="Steer left">‹</button>
          <button {...bindControl("right")} aria-label="Steer right">›</button>
        </div>
        <div className="drive-controls">
          <button className="nitro-button" {...bindControl("nitro")}>⚡<small>NITRO</small></button>
          <button className="brake-button" {...bindControl("brake")}>BRAKE</button>
          <button className="accelerate-button" {...bindControl("accel")}>GO ↑</button>
        </div>
      </div>}
      <footer><span>HIGHWAY RUSH 3D <i>•</i> BROWSER EDITION</span><span>DRIVE SAFE. RACE SMART.</span></footer>
    </main>
  );
}

export default App;
